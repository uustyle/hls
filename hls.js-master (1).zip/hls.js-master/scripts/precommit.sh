#!/bin/bash
npm run lint

